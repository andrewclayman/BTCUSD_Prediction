# src/train_sizer_sac.py
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from rl_sizer_env import CryptoSizerEnv
from stable_baselines3 import SAC
from stable_baselines3.common.vec_env import DummyVecEnv


def split_by_dates(df: pd.DataFrame, val_start: str, test_start: str):
    ts = pd.to_datetime(df["timestamp"], utc=True)
    val_s = pd.to_datetime(val_start, utc=True)
    test_s = pd.to_datetime(test_start, utc=True)
    tr = df[ts < val_s]
    va = df[(ts >= val_s) & (ts < test_s)]
    te = df[ts >= test_s]
    return tr.reset_index(drop=True), va.reset_index(drop=True), te.reset_index(drop=True)


def split_chrono_frac(df: pd.DataFrame, train_frac=0.6, val_frac=0.2):
    n = len(df)
    n_tr = int(n * train_frac)
    n_va = int(n * val_frac)
    tr = df.iloc[:n_tr].reset_index(drop=True)
    va = df.iloc[n_tr:n_tr + n_va].reset_index(drop=True)
    te = df.iloc[n_tr + n_va:].reset_index(drop=True)
    return tr, va, te


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--features", required=True)
    ap.add_argument("--preds", required=True)
    ap.add_argument("--regimes", default="")
    ap.add_argument("--val_start", default="2021-01-01")
    ap.add_argument("--test_start", default="2023-01-01")
    ap.add_argument("--force_frac", action="store_true",
                    help="Ignore dates and use 60/20/20 chronological split.")
    ap.add_argument("--lmax", type=float, default=3.0)
    ap.add_argument("--cost_bps", type=float, default=5.0)
    ap.add_argument("--thr", type=float, default=0.5)
    ap.add_argument("--delay", type=int, default=1)
    ap.add_argument("--steps", type=int, default=200_000)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    regimes_path = args.regimes if args.regimes else None
    df_all = CryptoSizerEnv.build_frame(args.features, args.preds, regimes_path)

    # Split logic
    if args.force_frac:
        tr, va, te = split_chrono_frac(df_all, train_frac=0.6, val_frac=0.2)
    else:
        tr, va, te = split_by_dates(df_all, args.val_start, args.test_start)
        # Fallback if train too small
        min_tr = 2000
        if len(tr) < min_tr:
            tr, va, te = split_chrono_frac(df_all, train_frac=0.6, val_frac=0.2)

    print(f"[data] lens TR={len(tr)} VA={len(va)} TE={len(te)} | "
          f"first={df_all['timestamp'].iloc[0]} last={df_all['timestamp'].iloc[-1]}")

    # Final safety
    for name, df in [("TR", tr), ("VA", va), ("TE", te)]:
        if len(df) <= args.delay + 2:
            raise ValueError(f"{name} split too small after preprocessing. "
                             f"Need > {args.delay + 2} rows, got {len(df)}. "
                             f"Use --force_frac or adjust dates.")

    def make_env(df):
        return lambda: CryptoSizerEnv(
            df,
            lmax=args.lmax,
            cost_bps=args.cost_bps,
            use_continuous_dir=True,
            thr=args.thr,
            delay=args.delay,
            dd_penalty=0.0,
        )

    # Train on TR
    env = DummyVecEnv([make_env(tr)])
    model = SAC(
        "MlpPolicy",
        env,
        verbose=0,
        learning_rate=1e-4,
        batch_size=512,
        gamma=0.999,
        tau=0.02,
        train_freq=(1, "step"),
        gradient_steps=1,
        buffer_size=min(500_000, len(tr) * 4),
        ent_coef="auto",
        target_entropy="auto",
    )
    model.learn(total_timesteps=args.steps)

    # Rollout on TE, produce time-aligned sizes
    env_te = CryptoSizerEnv(te, lmax=args.lmax, cost_bps=args.cost_bps,
                            use_continuous_dir=True, thr=args.thr, delay=args.delay)
    obs, _ = env_te.reset()
    sizes = []
    while True:
        act, _ = model.predict(obs, deterministic=True)
        obs, r, term, trunc, info = env_te.step(act)
        idx = env_te.t - 1
        if 0 <= idx < len(te):
            dir_mag = abs(env_te._dir_from_signal(float(te.loc[idx, "p_up"])))
            denom = dir_mag if dir_mag > 1e-9 else 1.0
            sizes.append({
                "timestamp": te.loc[idx, "timestamp"],
                "size": abs(env_te.pos_hist[-1]) / denom
            })
        if term or trunc:
            break

    out = pd.DataFrame(sizes).dropna()
    Path(args.out_dir).mkdir(parents=True, exist_ok=True)
    out_path = Path(args.out_dir) / "sizer_test.csv"
    out.to_csv(out_path, index=False)
    print(f"Wrote sizer -> {out_path}  rows={len(out)}")


if __name__ == "__main__":
    main()
