import argparse
from pathlib import Path

import numpy as np
import pandas as pd


HORIZONS = [6, 12, 24, 48, 96, 192, 216]  # hours ahead for training targets


def rsi(series: pd.Series, window: int = 24) -> pd.Series:
    # Classic Wilder's RSI (EMA of gains/losses)
    delta = series.diff()
    gain = (delta.clip(lower=0)).ewm(alpha=1/window, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/window, adjust=False).mean()
    rs = gain / (loss + 1e-12)
    return 100 - (100 / (1 + rs))


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def atr_df(df: pd.DataFrame, window: int = 24) -> pd.Series:
    # True Range components
    hl = df["high"] - df["low"]
    hc = (df["high"] - df["close"].shift()).abs()
    lc = (df["low"] - df["close"].shift()).abs()
    tr = pd.concat([hl, hc, lc], axis=1).max(axis=1)
    return tr.rolling(window).mean()


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    # 1) Basic returns
    out["ret_1h_log"] = np.log(out["close"] / out["close"].shift(1))

    # 2) Rolling volatility (std of 1h log returns)
    out["sigma24"] = out["ret_1h_log"].rolling(24).std()
    out["sigma72"] = out["ret_1h_log"].rolling(72).std()

    # 3) ATR(24)
    out["atr24"] = atr_df(out, window=24)

    # 4) EMAs on close
    out["ema24"] = ema(out["close"], 24)
    out["ema72"] = ema(out["close"], 72)
    out["ema168"] = ema(out["close"], 168)

    # 5) RSI(24) on close
    out["rsi24"] = rsi(out["close"], 24)

    # 6) Forward (future) log return targets for multi-horizon ER training
    for h in HORIZONS:
        out[f"fwd_logret_h{h}"] = np.log(out["close"].shift(-h) / out["close"])

    # 7) Housekeeping: drop rows with NaNs from rolling/shift edges
    out = out.dropna().reset_index(drop=True)

    return out


def read_btc_csv(path: Path) -> pd.DataFrame:
    # Expected columns: unix,date,symbol,open,high,low,close,Volume BTC,Volume USD
    df = pd.read_csv(path)
    # Prefer the 'date' column (already human-readable). Treat as UTC.
    df["timestamp"] = pd.to_datetime(df["date"], utc=True)
    df = df.sort_values("timestamp").reset_index(drop=True)

    # Standardize column names
    keep = {
        "timestamp": "timestamp",
        "open": "open",
        "high": "high",
        "low": "low",
        "close": "close",
        "Volume BTC": "volume_btc",
        "Volume USD": "volume_usd",
        "symbol": "symbol",
    }
    df = df[list(keep.keys())].rename(columns=keep)
    return df


def main():
    ap = argparse.ArgumentParser(description="Build hourly BTCUSD features + targets.")
    ap.add_argument("--in", dest="inp", required=True, help="Path to BTCUSD.csv")
    ap.add_argument("--out", dest="out", required=True, help="Path to output .parquet")
    args = ap.parse_args()

    src = Path(args.inp)
    dst = Path(args.out)
    dst.parent.mkdir(parents=True, exist_ok=True)

    raw = read_btc_csv(src)
    feats = build_features(raw)

    # Save parquet (fast + preserves types)
    feats.to_parquet(dst, index=False)
    print(f"Wrote features: {dst}  | rows={len(feats)}  cols={len(feats.columns)}")


if __name__ == "__main__":
    main()
