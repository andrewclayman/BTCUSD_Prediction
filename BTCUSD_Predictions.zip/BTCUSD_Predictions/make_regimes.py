# src/make_regimes.py
import argparse
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--features", required=True, help="BTC features parquet with timestamp, close")
    ap.add_argument("--preds", required=True, help="moe_preds.parquet with timestamp,p_up")
    ap.add_argument("--out", required=True, help="Output parquet with columns [timestamp, regime]")
    ap.add_argument("--vol_w1", type=int, default=24)
    ap.add_argument("--vol_w2", type=int, default=72)
    ap.add_argument("--mom_w", type=int, default=24)
    ap.add_argument("--n_states", type=int, default=3)
    args = ap.parse_args()

    f = pd.read_parquet(args.features)[["timestamp","close"]].copy()
    f["timestamp"] = pd.to_datetime(f["timestamp"], utc=True)
    f = f.dropna().sort_values("timestamp")

    # hourly simple returns
    ret = f["close"].pct_change().replace([np.inf,-np.inf], np.nan).fillna(0.0)
    f["vol1"] = ret.rolling(args.vol_w1, min_periods=args.vol_w1//2).std()
    f["vol2"] = ret.rolling(args.vol_w2, min_periods=args.vol_w2//2).std()
    f["mom"]  = f["close"].pct_change(args.mom_w)

    # one-bar lag to avoid using the current bar’s realized stats
    for c in ("vol1","vol2","mom"):
        f[c] = f[c].shift(1)

    # merge p_up for optional use (clipped, lagged)
    p = pd.read_parquet(args.preds)[["timestamp","p_up"]].copy()
    p["timestamp"] = pd.to_datetime(p["timestamp"], utc=True)
    p = p.dropna().sort_values("timestamp")
    df = f.merge(p, on="timestamp", how="inner")
    df["p_up"] = df["p_up"].clip(0,1).shift(1)
    df = df.dropna().reset_index(drop=True)

    X = df[["vol1","vol2","mom"]].values
    # impute mild values if any residual NaNs
    m = np.nanmean(X, axis=0); m[np.isnan(m)] = 0.0
    where = np.where(np.isnan(X)); X[where] = np.take(m, where[1])

    k = KMeans(n_clusters=args.n_states, n_init=20, random_state=42)
    lab = k.fit_predict(X)

    # order regimes by volatility (low→mid→high) for interpretability
    means = pd.DataFrame({"lab": lab, "vol": df["vol2"].values}).groupby("lab")["vol"].mean().sort_values()
    remap = {old:i for i, old in enumerate(means.index)}
    df["regime"] = [remap[x] for x in lab]

    out = df[["timestamp","regime"]].copy()
    out.to_parquet(args.out, index=False)
    print(f"Wrote regimes -> {args.out} | states={args.n_states} | counts={out['regime'].value_counts().to_dict()}")

if __name__ == "__main__":
    main()
