# walkforward_baseline.py
import argparse
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd


# -----------------------------
# Utilities
# -----------------------------
def to_utc_ts(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, utc=True, errors="coerce")


def load_features(path: str) -> pd.DataFrame:
    df = pd.read_parquet(path)
    if "timestamp" not in df or "close" not in df:
        raise ValueError("features parquet must contain 'timestamp' and 'close'.")
    df = df[["timestamp", "close"]].copy()
    df["timestamp"] = to_utc_ts(df["timestamp"])
    df = df.dropna(subset=["timestamp", "close"]).sort_values("timestamp").reset_index(drop=True)
    return df


def load_preds(path: str) -> pd.DataFrame:
    df = pd.read_parquet(path)
    if "timestamp" not in df or "p_up" not in df:
        raise ValueError("preds parquet must contain 'timestamp' and 'p_up'.")
    df = df[["timestamp", "p_up"]].copy()
    df["timestamp"] = to_utc_ts(df["timestamp"])
    df = df.dropna(subset=["timestamp", "p_up"]).sort_values("timestamp").reset_index(drop=True)
    return df


def compute_simple_returns(prices: pd.Series) -> pd.Series:
    ret = prices.pct_change()
    ret = ret.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return ret


def position_from_probs(
    p: np.ndarray,
    thr: float,
    band_low: Optional[float],
    band_high: Optional[float],
    long_only: bool,
) -> np.ndarray:
    """
    Base position before sizing:
      • If bands are provided: long above band_high, short below band_low (or flat if long_only).
      • Else: thresholded long/short or long-only around thr.
    Returns vector in {-1,0,1} or {0,1}.
    """
    if band_low is not None and band_high is not None:
        y = np.zeros_like(p, dtype=float)
        if long_only:
            y[p >= band_high] = 1.0
        else:
            y[p >= band_high] = 1.0
            y[p <= band_low] = -1.0
        return y

    if long_only:
        return (p >= thr).astype(float)
    return np.where(p >= thr, 1.0, -1.0).astype(float)


def apply_delay(y: np.ndarray, delay: int) -> np.ndarray:
    if delay <= 0:
        return y
    yd = np.roll(y, delay)
    yd[:delay] = 0.0
    return yd


def per_change_cost_bps(
    pos: np.ndarray,
    fee_bps: float,
    spread_bps: Optional[float] = None,
    spread_bps_series: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Transaction cost charged on *position changes* (entries/exits/flip).
    Model: cost_per_change = |Δpos| * (fee_bps + spread_bps_effective) * 1e-4
      • fee_bps is per-change (covers taker/maker or commissions in bps of notional).
      • spread_bps is total bid-ask width in bps; we apply it on *each change*.
      • If spread_bps_series is provided, it overrides static spread_bps per bar.
    """
    if len(pos) == 0:
        return np.zeros(0, dtype=float)

    delta = np.diff(pos, prepend=pos[0])
    mag = np.abs(delta)

    if spread_bps_series is not None:
        spread_term = np.asarray(spread_bps_series, dtype=float)
        spread_term[~np.isfinite(spread_term)] = 0.0
    else:
        spread_term = np.full_like(mag, float(spread_bps or 0.0), dtype=float)

    fees = float(fee_bps)
    total_bps = np.maximum(0.0, fees) + np.maximum(0.0, spread_term)
    return mag * total_bps * 1e-4


def volatility_targeting(
    gross: pd.Series,
    costs: pd.Series,
    ret_underlying: pd.Series,
    target_vol_annual: float,
    vol_window: int,
    bars_per_year: float,
    leverage_cap: Optional[float],
) -> tuple[pd.Series, pd.Series]:
    """
    Scale gross returns and costs by k_t = target / realized_vol_t,
    where realized_vol_t is rolling annualized std of underlying returns.
    """
    if target_vol_annual <= 0:
        return gross, costs

    roll_sd = ret_underlying.rolling(vol_window, min_periods=max(5, vol_window // 4)).std(ddof=0)
    realized = roll_sd * np.sqrt(bars_per_year)
    realized = realized.bfill().fillna(ret_underlying.std(ddof=0) * np.sqrt(bars_per_year) or 1e-6)

    k = target_vol_annual / realized.replace(0.0, np.nan)
    k = k.fillna(0.0)
    if leverage_cap is not None and leverage_cap > 0:
        k = k.clip(lower=0.0, upper=float(leverage_cap))

    return gross * k, costs * k.abs()


# -----------------------------
# Core backtest
# -----------------------------
def run_backtest(
    df: pd.DataFrame,
    thr: float,
    band_low: Optional[float],
    band_high: Optional[float],
    delay: int,
    fee_bps: float,
    spread_bps: Optional[float],
    long_only: bool,
    invert: bool,
    target_vol_annual: float,
    vol_window: int,
    bars_per_year: float,
    leverage_cap: Optional[float],
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """
    Returns:
      net -> per-bar net simple returns after costs
      pos -> position series (possibly sized)
      eq  -> equity curve (starting at 1.0)
    Expects df columns: timestamp, close, p_up, size (optional), spread_bps (optional)
    """
    p = df["p_up"].to_numpy(dtype=float)
    if invert:
        p = 1.0 - p

    # Base position in {-1,0,1} or {0,1}
    base_pos = position_from_probs(p, thr, band_low, band_high, long_only)

    # Optional external sizer in [0, cap]
    if "size" in df.columns:
        size = df["size"].to_numpy(dtype=float)
        size = np.where(np.isfinite(size), size, np.nan)
        if leverage_cap is not None:
            size = np.clip(size, 0.0, float(leverage_cap))
        # default size=1 when NaN
        size = np.where(np.isnan(size), 1.0, size)
    else:
        size = np.ones_like(base_pos, dtype=float)

    pos = base_pos * size
    pos = apply_delay(pos, delay)
    pos_series = pd.Series(pos, index=pd.to_datetime(df["timestamp"], utc=True))

    # Returns of underlying
    ret = compute_simple_returns(df["close"])
    ret.index = pd.to_datetime(df["timestamp"], utc=True)

    gross = pos_series * ret

    # Dynamic or static spread
    spread_series = None
    if "spread_bps" in df.columns:
        spread_series = df["spread_bps"].to_numpy(dtype=float)

    cost = pd.Series(per_change_cost_bps(pos, fee_bps=fee_bps, spread_bps=spread_bps, spread_bps_series=spread_series),
                     index=pos_series.index)

    gross_adj, cost_adj = volatility_targeting(
        gross=gross,
        costs=cost,
        ret_underlying=ret,
        target_vol_annual=target_vol_annual,
        vol_window=vol_window,
        bars_per_year=bars_per_year,
        leverage_cap=leverage_cap,
    )

    net = gross_adj - cost_adj
    net = net.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    eq = (1.0 + net).cumprod()

    return net, pos_series, eq


def summarize_and_write(
    net: pd.Series,
    eq: pd.Series,
    pos: pd.Series,
    out_path: Path,
    summary_csv: Optional[Path],
    bars_per_year: float,
    thr: float,
    band_low: Optional[float],
    band_high: Optional[float],
    long_only: bool,
    invert: bool,
) -> None:
    # Diagnostics
    ppyear = float(bars_per_year)
    test_n = int(len(net))
    span = f"{net.index.min()} .. {net.index.max()}"

    mu = float(net.mean()) * ppyear
    sd = float(net.std(ddof=0)) * (ppyear ** 0.5)
    sharpe = (mu / sd) if sd > 0 else 0.0

    years = test_n / ppyear if ppyear > 0 else 1.0
    cagr = float(eq.iloc[-1]) ** (1.0 / max(years, 1e-12)) - 1.0
    maxdd = float((eq / eq.cummax() - 1.0).min())

    # Per-bar equity file
    out_df = pd.DataFrame({
        "timestamp": net.index,
        "ret_net": net.values,
        "equity": eq.values,
        "position": pos.values,
    })
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)

    # Monthly table and statistics
    # Use 'M' (month-end) to avoid the older 'ME' ValueError in some pandas builds
    monthly = net.resample("M").sum()
    monthly_df = pd.DataFrame({
        "month": monthly.index,
        "ret_sum": monthly.values,
        "cum_equity": (1.0 + monthly).cumprod()
    })
    monthly_out = out_path.with_suffix(".monthly.csv")
    monthly_df.to_csv(monthly_out, index=False)

    # Monthly summary in console
    m_count = int(monthly.shape[0])
    m_mu = float(monthly.mean()) if m_count > 0 else 0.0
    m_sd = float(monthly.std(ddof=0)) if m_count > 0 else 0.0
    m_sharpe_ann = (m_mu / m_sd * np.sqrt(12.0)) if m_sd > 0 else 0.0
    m_pos_frac = float((monthly > 0).mean()) if m_count > 0 else 0.0
    m_best = float(monthly.max()) if m_count > 0 else 0.0
    m_worst = float(monthly.min()) if m_count > 0 else 0.0

    tail_rows = min(6, m_count)
    if tail_rows > 0:
        tail = monthly_df.tail(tail_rows)
        print(f"[monthly] N_months={m_count}  mean={m_mu:.4f}  sd={m_sd:.4f}  Sharpe_ann≈{m_sharpe_ann:.2f}  "
              f"pos_month_frac={m_pos_frac:.2f}  best={m_best:+.4f}  worst={m_worst:+.4f}")
        print("[monthly] tail(6):")
        for _, r in tail.iterrows():
            mstr = pd.Timestamp(r["month"]).strftime("%Y-%m")
            print(f"  {mstr}: ret={r['ret_sum']:+.4f}  cum_eq={r['cum_equity']:.3f}")

    print(
        f"[single] Span={span}  bars={test_n}  | Sharpe={sharpe:.2f}  CAGR={cagr*100:.2f}%  "
        f"MaxDD={maxdd*100:.2f}%  thr={thr:.3f} band=[{(band_low if band_low is not None else 0.0):.2f},"
        f"{(band_high if band_high is not None else 1.0):.2f}] long_only={bool(long_only)} invert={invert}"
    )
    print(f"[single] Wrote per-bar equity -> {out_path}")
    print(f"[single] Monthly table -> {monthly_out}")

    # Optional summary append
    if summary_csv is not None:
        row = {
            "out": str(out_path),
            "span_start": str(net.index.min()),
            "span_end": str(net.index.max()),
            "bars": test_n,
            "sharpe": sharpe,
            "cagr": cagr,
            "maxdd": maxdd,
            "thr": thr,
            "band_low": band_low,
            "band_high": band_high,
            "long_only": bool(long_only),
            "invert": invert,
        }
        sc = Path(summary_csv)
        if sc.exists():
            sd = pd.read_csv(sc)
            sd = pd.concat([sd, pd.DataFrame([row])], ignore_index=True)
        else:
            sd = pd.DataFrame([row])
        sd.to_csv(sc, index=False)
        print(f"[single] Appended summary -> {sc}")


# -----------------------------
# CLI
# -----------------------------
def main():
    ap = argparse.ArgumentParser(description="Simple backtest from probability predictions with fees/spread/sizer.")
    # IO
    ap.add_argument("--features", required=True, help="Parquet with 'timestamp' and 'close'")
    ap.add_argument("--preds", required=True, help="Parquet with 'timestamp' and 'p_up'")
    ap.add_argument("--out", required=True, help="CSV path for per-bar equity output")
    ap.add_argument("--summary_csv", default=None, help="CSV path to append a summary row")

    # Horizon label (for bookkeeping only)
    ap.add_argument("--h", type=int, default=12, help="Horizon label")

    # Trading rule
    ap.add_argument("--thr", type=float, default=0.50, help="Threshold for long/short or long-only")
    ap.add_argument("--band_low", type=float, default=None, help="Confidence band low; enables band trading")
    ap.add_argument("--band_high", type=float, default=None, help="Confidence band high; enables band trading")
    ap.add_argument("--long_only", action="store_true", help="Use long-only rules")
    ap.add_argument("--invert", action="store_true", help="Invert probabilities p -> 1-p")
    ap.add_argument("--delay", type=int, default=1, help="Bars to delay signal execution")

    # Costs: explicit fee and spread
    ap.add_argument("--fee_bps", type=float, default=0.0, help="Per-change transaction fee in bps")
    ap.add_argument("--spread_bps", type=float, default=None, help="Static bid-ask spread in bps (applied on changes)")
    ap.add_argument("--spread_csv", type=str, default=None,
                    help="CSV with columns [timestamp, spread_bps] for time-varying spread")

    # Optional external sizer (learned RL sizer)
    ap.add_argument("--sizer_csv", default=None, help="Optional CSV with [timestamp,size] in [0, leverage_cap or Lmax]")

    # Vol targeting
    ap.add_argument("--target_vol_annual", type=float, default=0.0, help="Annualized target vol; 0 disables")
    ap.add_argument("--vol_window", type=int, default=48, help="Rolling window (bars) for realized vol")
    ap.add_argument("--leverage_cap", type=float, default=None, help="Cap on leverage multiplier or sizer values")

    # Annualization
    ap.add_argument("--bars_per_year", type=float, default=8760.0,
                    help="Annualization factor. 8760 for hourly crypto; 252 for daily equities; 365 for daily crypto.")

    args = ap.parse_args()

    # Load and merge
    feat = load_features(args.features)
    preds = load_preds(args.preds)

    df = feat.merge(preds, on="timestamp", how="inner")
    if df.empty:
        raise ValueError("Merged features/preds is empty. Time ranges may not overlap.")
    df = df.sort_values("timestamp").reset_index(drop=True)

    # Optional sizer
    if args.sizer_csv:
        s = pd.read_csv(args.sizer_csv)
        if "timestamp" not in s.columns and "Date" in s.columns:
            s = s.rename(columns={"Date": "timestamp"})
        s["timestamp"] = to_utc_ts(s["timestamp"])
        s = s.dropna(subset=["timestamp"])
        if "size" not in s.columns:
            raise ValueError("--sizer_csv must contain a 'size' column.")
        s = s[["timestamp", "size"]]
        df = df.merge(s, on="timestamp", how="left")
        df["size"] = pd.to_numeric(df["size"], errors="coerce")

    # Optional time-varying spread
    if args.spread_csv:
        sc = pd.read_csv(args.spread_csv)
        if "timestamp" not in sc.columns and "Date" in sc.columns:
            sc = sc.rename(columns={"Date": "timestamp"})
        if "spread_bps" not in sc.columns:
            raise ValueError("--spread_csv must contain a 'spread_bps' column.")
        sc["timestamp"] = to_utc_ts(sc["timestamp"])
        sc = sc.dropna(subset=["timestamp", "spread_bps"])
        sc["spread_bps"] = pd.to_numeric(sc["spread_bps"], errors="coerce")
        df = df.merge(sc[["timestamp", "spread_bps"]], on="timestamp", how="left")

    # Backtest
    net, pos, eq = run_backtest(
        df=df,
        thr=float(args.thr),
        band_low=(None if args.band_low is None else float(args.band_low)),
        band_high=(None if args.band_high is None else float(args.band_high)),
        delay=int(args.delay),
        fee_bps=float(args.fee_bps),
        spread_bps=(None if args.spread_bps is None else float(args.spread_bps)),
        long_only=bool(args.long_only),
        invert=bool(args.invert),
        target_vol_annual=float(args.target_vol_annual),
        vol_window=int(args.vol_window),
        bars_per_year=float(args.bars_per_year),
        leverage_cap=(None if args.leverage_cap is None else float(args.leverage_cap)),
    )

    # Write outputs and summary
    out_path = Path(args.out)
    summary_csv = Path(args.summary_csv) if args.summary_csv else None
    summarize_and_write(
        net=net, eq=eq, pos=pos,
        out_path=out_path,
        summary_csv=summary_csv,
        bars_per_year=float(args.bars_per_year),
        thr=float(args.thr),
        band_low=(None if args.band_low is None else float(args.band_low)),
        band_high=(None if args.band_high is None else float(args.band_high)),
        long_only=bool(args.long_only),
        invert=bool(args.invert),
    )


if __name__ == "__main__":
    pd.options.mode.copy_on_write = True
    main()
