# src/rl_sizer_env.py
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd


class CryptoSizerEnv(gym.Env):
    """
    Position sizing around a directional signal p_up.
    State includes recent signal stats, returns, and one-hot regimes.
    Action is size in [0, Lmax]. Executed position is delayed by `delay`.
    Reward is net PnL minus costs, with optional drawdown penalty.
    """
    metadata = {"render_modes": []}

    def __init__(
        self,
        df: pd.DataFrame,
        lmax: float = 3.0,
        cost_bps: float = 5.0,
        use_continuous_dir: bool = True,
        thr: float = 0.5,
        signal_scale: float = 4.0,
        delay: int = 1,
        dd_penalty: float = 0.0,
    ):
        super().__init__()
        self.df = df.reset_index(drop=True).copy()
        self.T = len(self.df)
        self.lmax = float(lmax)
        self.cost = float(cost_bps) * 1e-4
        self.use_continuous_dir = bool(use_continuous_dir)
        self.thr = float(thr)
        self.signal_scale = float(signal_scale)
        self.delay = int(delay)
        self.dd_penalty = float(dd_penalty)

        # Observation columns (use only those that exist)
        base_obs = ["p_up", "p_ma24", "p_sd24", "ret1", "ret24", "reg0", "reg1", "reg2"]
        self.obs_cols = [c for c in base_obs if c in self.df.columns]
        if not self.obs_cols:
            raise ValueError("No observation columns found. Expected any of: " + ", ".join(base_obs))

        self.observation_space = spaces.Box(
            low=-10.0, high=10.0, shape=(len(self.obs_cols),), dtype=np.float32
        )
        self.action_space = spaces.Box(low=0.0, high=self.lmax, shape=(1,), dtype=np.float32)

        # Need at least delay+3 rows to step safely
        if self.T <= self.delay + 2:
            raise ValueError(f"Dataset too small for delay={self.delay}. Need > {self.delay+2} rows, got {self.T}.")

        self.pos_hist = None
        self.eq = None
        self.t = None

    def _dir_from_signal(self, p: float) -> float:
        if self.use_continuous_dir:
            return float(np.tanh(self.signal_scale * (p - 0.5)))  # (-1, 1)
        return float(1.0 if p >= self.thr else -1.0)

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        # start at 1 + delay so we have a valid executed position reference
        self.t = 1 + self.delay
        self.pos_hist = [0.0] * self.t
        self.eq = [1.0] * self.t
        return self._obs(self.t), {}

    def _obs(self, t: int):
        # Use iloc for position-based indexing; avoids label pitfalls
        x = self.df.loc[:, self.obs_cols].iloc[t].astype(float).to_numpy()
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        return x.astype(np.float32)

    def step(self, action):
        a = float(np.clip(action[0], 0.0, self.lmax))

        p = float(self.df["p_up"].iloc[self.t])
        d = self._dir_from_signal(p)
        desired_pos = a * d  # [-Lmax, Lmax]

        prev_pos = self.pos_hist[-1]
        exec_pos = self.pos_hist[-1 - self.delay] if len(self.pos_hist) > self.delay else 0.0

        r = float(self.df["ret1"].iloc[self.t])
        gross = exec_pos * r

        tc = abs(desired_pos - prev_pos) * self.cost
        net = gross - tc

        if self.dd_penalty > 0:
            new_eq = self.eq[-1] * (1.0 + net)
            peak = max(self.eq)
            dd = 0.0 if peak <= 0 else (new_eq / peak - 1.0)
            net += self.dd_penalty * min(0.0, dd)

        self.pos_hist.append(desired_pos)
        self.eq.append(self.eq[-1] * (1.0 + net))
        self.t += 1

        terminated = self.t >= self.T - 1
        truncated = False
        obs = self._obs(self.t if not terminated else self.T - 1)
        info = {
            "net": float(net),
            "gross": float(gross),
            "cost": float(tc),
            "pos": float(desired_pos),
            "exec_pos": float(exec_pos),
        }
        return obs, float(net), terminated, truncated, info

    @staticmethod
    def build_frame(features_path: str, preds_path: str, regimes_path: str | None = None) -> pd.DataFrame:
        f = pd.read_parquet(features_path)[["timestamp", "close"]].copy()
        f["timestamp"] = pd.to_datetime(f["timestamp"], utc=True, errors="coerce")
        f = f.dropna().sort_values("timestamp").reset_index(drop=True)

        # returns
        f["ret1"] = f["close"].pct_change().replace([np.inf, -np.inf], np.nan).fillna(0.0)
        f["ret24"] = f["close"].pct_change(24).shift(1)

        p = pd.read_parquet(preds_path)[["timestamp", "p_up"]].copy()
        p["timestamp"] = pd.to_datetime(p["timestamp"], utc=True, errors="coerce")
        p = p.dropna().sort_values("timestamp").reset_index(drop=True)

        df = f.merge(p, on="timestamp", how="inner").dropna().reset_index(drop=True)

        # lag signal features one bar for safety
        df["p_up"] = df["p_up"].clip(0, 1).shift(1)
        df["p_ma24"] = df["p_up"].rolling(24, min_periods=6).mean().shift(1)
        df["p_sd24"] = df["p_up"].rolling(24, min_periods=6).std().shift(1)

        # regimes
        if regimes_path:
            r = pd.read_parquet(regimes_path)[["timestamp", "regime"]].copy()
            r["timestamp"] = pd.to_datetime(r["timestamp"], utc=True, errors="coerce")
            df = df.merge(r, on="timestamp", how="left")
        else:
            df["regime"] = 1.0

        max_reg = int(np.nanmax(df["regime"])) if df["regime"].notna().any() else 0
        for k in range(max_reg + 1):
            col = f"reg{k}"
            df[col] = (df["regime"] == k).astype(float).shift(1)

        keep = ["timestamp", "close", "ret1", "ret24", "p_up", "p_ma24", "p_sd24"] + \
               [c for c in df.columns if c.startswith("reg")]
        df = df[keep].dropna().reset_index(drop=True)
        return df
